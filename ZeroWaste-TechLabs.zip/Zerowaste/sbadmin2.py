#!/usr/bin/env python
from flask import Flask, url_for, render_template
import jinja2.exceptions
import pandas as pd
import json
import plotly
import plotly.express as px
import matplotlib.pyplot as plt

app = Flask(__name__)

@app.route('/')
def landing():
    return render_template('Projekt_html.html')

@app.route('/dashboard')
def index():
	df = pd.DataFrame({
		'Fruit': ['Apples', 'Oranges', 'Bananas', 'Apples', 'Oranges', 'Bananas'],
        'Amount': [4, 1, 2, 2, 4, 5],
        'City': ['SF', 'SF', 'SF', 'Montreal', 'Montreal', 'Montreal']
        })
	fig = px.bar(df, x='Fruit', y='Amount', color='City',    barmode='group')
	graphJSON = json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)
	fig_pie = px.pie(df, values='Amount', names='City', title='')
	graphJSON2 = json.dumps(fig_pie, cls=plotly.utils.PlotlyJSONEncoder)
	return render_template('index.html', graphJSON=graphJSON, graphJSON2=graphJSON2)

@app.route('/register')
def reg():
    return render_template('Register.html')

@app.route('/login')
def log():
    return render_template('LogIn.html')

@app.route('/contact')
def con():
    return render_template('Contact Us.html')

@app.errorhandler(jinja2.exceptions.TemplateNotFound)
def template_not_found(e):
    return not_found(e)

@app.errorhandler(404)
def not_found(e):
    return render_template('404.html')

if __name__ == '__main__':
    app.run(debug=True)
